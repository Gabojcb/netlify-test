"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _default = {
  "package": "practice",
  "version": "0.0.1",
  "languages": {
    "default": "en",
    "supported": ["en", "es"]
  },
  "global.css": true,
  "params": {},
  "ssr": {},
  "backend": {}
};
exports.default = _default;