import type { IWidgetStore } from '@beyond-js/widgets/controller';
export class StoreManager implements IWidgetStore {}
